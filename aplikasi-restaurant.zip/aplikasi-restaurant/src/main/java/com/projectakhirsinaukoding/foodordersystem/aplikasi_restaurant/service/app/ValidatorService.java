package com.projectakhirsinaukoding.foodordersystem.aplikasi_restaurant.service.app;

public interface ValidatorService {

    void validator(Object data);

}
