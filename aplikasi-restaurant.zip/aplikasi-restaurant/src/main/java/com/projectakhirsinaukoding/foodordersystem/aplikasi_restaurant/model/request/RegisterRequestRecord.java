package com.projectakhirsinaukoding.foodordersystem.aplikasi_restaurant.model.request;

public record RegisterRequestRecord() {
}
