package com.projectakhirsinaukoding.foodordersystem.aplikasi_restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MainAppTests {

	@Test
	void contextLoads() {
	}

}
